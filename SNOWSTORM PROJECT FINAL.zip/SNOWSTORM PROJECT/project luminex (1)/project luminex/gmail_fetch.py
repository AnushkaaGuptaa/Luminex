import sqlite3
import json
import os
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request

from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

conn = sqlite3.connect("emails.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS emails (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender TEXT,
    subject TEXT,
    snippet TEXT
)
""")

conn.commit()

SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']

creds = None

if os.path.exists('token.json'):
    creds = Credentials.from_authorized_user_file('token.json', SCOPES)

if not creds or not creds.valid:
    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())
    else:
        flow = InstalledAppFlow.from_client_secrets_file(
            'credentials.json', SCOPES)
        creds = flow.run_local_server(port=0)

    with open('token.json', 'w') as token:
        token.write(creds.to_json())


with open('token.json', 'w') as token:
    token.write(creds.to_json())

service = build('gmail', 'v1', credentials=creds)

results = service.users().messages().list(
    userId='me', maxResults=5).execute()

messages = results.get('messages', [])

emails_data = []

print("\nFetched Emails:\n")

for msg in messages:
    msg_data = service.users().messages().get(
        userId='me', id=msg['id']).execute()

    headers = msg_data['payload']['headers']

    sender = "Not found"
    subject = "Not found"

    for header in headers:
        if header['name'] == 'From':
            sender = header['value']
        if header['name'] == 'Subject':
            subject = header['value']

    snippet = msg_data.get('snippet')

    email_object = {
        "from": sender,
        "subject": subject,
        "snippet": snippet
    }

    emails_data.append(email_object)
    
    cursor.execute(
        "INSERT INTO emails (sender, subject, snippet) VALUES (?, ?, ?)",
        (sender, subject, snippet)
    )
    conn.commit()


with open("emails.json", "w", encoding="utf-8") as f:
    json.dump(emails_data, f, indent=4)

print("Emails saved to emails.json")


from flask import Flask, jsonify
import json
import os

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
EMAILS_FILE = os.path.join(BASE_DIR, "project luminex", "emails.json")

@app.route("/emails")
def emails():
    with open(EMAILS_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    return jsonify(data[:10])


if __name__ == "__main__":
    app.run(port=5000, debug=True)

import streamlit as st
import requests
import re
import uuid

# ===============================
# CONFIG
# ===============================
API_URL = "http://127.0.0.1:5000/emails"

st.set_page_config(page_title="AI Email Assistant", layout="wide")

st.markdown(
    "<h1 style='text-align: center; color: #1f77b4;'>📩 AI-Powered Daily Email Summary</h1>",
    unsafe_allow_html=True,
)
st.markdown(
    "<p style='text-align: center; color: gray;'>Privacy-first assistant highlighting important emails, deadlines, and reminders</p>",
    unsafe_allow_html=True,
)

# ===============================
# LOAD EMAILS
# ===============================
@st.cache_data(show_spinner=False)
def load_emails():
    res = requests.get(API_URL)
    data = res.json()

    # 🔐 ensure every email has a UNIQUE id
    for e in data:
        if "id" not in e or not e["id"]:
            e["id"] = str(uuid.uuid4())
    return data


if "emails" not in st.session_state:
    st.session_state.emails = load_emails()

# ===============================
# AI / NLP HELPERS
# ===============================
def is_important(email):
    urgent_words = ["urgent", "immediately", "asap", "important", "deadline", "submit"]
    text = (email.get("snippet", "") + " " + email.get("subject", "")).lower()
    return any(word in text for word in urgent_words)


def extract_deadline(email):
    text = email.get("snippet", "")
    match = re.search(r"\b(today|tomorrow|by\s[\w\s:]+)\b", text, re.IGNORECASE)
    return match.group(0) if match else None


# ===============================
# ANNOTATE EMAILS
# ===============================
for e in st.session_state.emails:
    e["important"] = e.get("important", is_important(e))
    e["deadline"] = e.get("deadline", extract_deadline(e))
    e["done"] = e.get("done", False)

# ===============================
# SUMMARY CARDS
# ===============================
important_emails = [e for e in st.session_state.emails if e["important"] and not e["done"]]
deadlines = [e for e in st.session_state.emails if e["deadline"] and not e["done"]]
total_active = [e for e in st.session_state.emails if not e["done"]]

col1, col2, col3 = st.columns(3)

with col1:
    st.markdown(
        f"""
        <div style='background-color:#ffcccc; padding:15px; border-radius:10px; text-align:center;'>
            <h3>🔥 Urgent Emails</h3>
            <h2>{len(important_emails)}</h2>
        </div>
        """,
        unsafe_allow_html=True,
    )

with col2:
    st.markdown(
        f"""
        <div style='background-color:#cce5ff; padding:15px; border-radius:10px; text-align:center;'>
            <h3>⏰ Deadlines</h3>
            <h2>{len(deadlines)}</h2>
        </div>
        """,
        unsafe_allow_html=True,
    )

with col3:
    st.markdown(
        f"""
        <div style='background-color:#d4edda; padding:15px; border-radius:10px; text-align:center;'>
            <h3>📨 Total Emails</h3>
            <h2>{len(total_active)}</h2>
        </div>
        """,
        unsafe_allow_html=True,
    )

# ===============================
# DEADLINES LIST
# ===============================
if deadlines:
    st.markdown("### 📝 Deadlines Detected")
    for e in deadlines:
        st.markdown(f"- **{e.get('subject', 'No Subject')}** | ⏰ {e['deadline']}")

st.divider()

# ===============================
# EMAIL CARDS
# ===============================
st.subheader("📩 Email Overview & Actions")

for email in st.session_state.emails:
    if email["done"]:
        continue

    card_color = "#fff3cd" if email["important"] else "#f0f0f0"

    with st.container():
        st.markdown(
            f"<div style='background-color:{card_color}; padding:15px; border-radius:10px;'></div>",
            unsafe_allow_html=True,
        )

        cols = st.columns([3, 4, 1, 1])

        with cols[0]:
            st.write(f"**From:** {email.get('from', 'Unknown')}")
            st.write(f"**Subject:** {email.get('subject', 'No Subject')}")

        with cols[1]:
            st.write(email.get("snippet", ""))

        with cols[2]:
            if st.button(
                "✅ Done",
                key=f"done_{email['id']}",
            ):
                email["done"] = True
                st.rerun()

        with cols[3]:
            if st.button(
                "⭐" if not email["important"] else "❌",
                key=f"star_{email['id']}",
            ):
                email["important"] = not email["important"]
                st.rerun()
